import java.util.Scanner;

/**
 *
 * @author sandra yolotzin
 */
public class EJERCICIO1_SEGURIDADYVIRTUALIZACION {

    /**
     * @param args the command line arguments
     */
    

    public static void main(String[] args) {
        // Creamos un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Pedimos al usuario que ingrese una contraseña
        System.out.println("Ingresa tu contraseña: ");
        String password = scanner.nextLine();

        // Verificamos si la contraseña es segura utilizando el método isSecurePassword
        if (isSecurePassword(password)) {
            // Si la contraseña es segura, se muestra un mensaje de confirmación
            System.out.println("La contraseña es segura.");
        } else {
            // Si la contraseña no es segura, se mostrará un mensaje de advertencia con los criterios que debe cumplir
            System.out.println("La contraseña no es segura. Asegúrate de que cumpla los siguientes requisitos:");
            System.out.println("- Al menos 8 caracteres");
            System.out.println("- Al menos una letra mayúscula");
            System.out.println("- Al menos una letra minúscula");
            System.out.println("- Al menos un número");
            System.out.println("- Al menos un carácter especial (@, #, $, etc.)");
            System.out.println("- No debe contener espacios en blanco");
            System.out.println("- No debe tener letras iguales consecutivas");
        }

        scanner.close();
    }

    // Método que verifica si la contraseña es segura según los criterios dados
    public static boolean isSecurePassword(String password) {
        if (password.length() < 8) {
            return false;
        }

        // Variables booleanas para verificar los diferentes criterios de seguridad
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;
        boolean hasNoSpaces = !password.contains(" ");

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasUpperCase = true;
            } else if (Character.isLowerCase(c)) {
                hasLowerCase = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if ("@#$%^&+=!".contains(String.valueOf(c))) {
                hasSpecialChar = true;
            }

            // Verificar si hay letras iguales consecutivas
            if (i > 0 && password.charAt(i) == password.charAt(i - 1)) {
                return false;
            }
        }

        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar && hasNoSpaces;
    }
}
