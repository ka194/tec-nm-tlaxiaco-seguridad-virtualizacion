import java.util.Random;

/**
 *
 * @author sandra yolotzin
 */
public class EJERCICIO2_SEGURIDADYVIRTUALIZACION {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        String securePassword = generateSecurePassword(12); // Se puede cambiar el tamaño de la contraseña si es necesario
        System.out.println("Contraseña segura recomendada: " + securePassword);
    }

    public static String generateSecurePassword(int length) {
        String upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
        String digits = "0123456789";
        String specialCharacters = "@#$%^&+=!";
        String allCharacters = upperCaseLetters + lowerCaseLetters + digits + specialCharacters;

        Random random = new Random();
        StringBuilder password = new StringBuilder();

        // Asegurar que la contraseña contenga al menos un carácter de cada tipo
        password.append(upperCaseLetters.charAt(random.nextInt(upperCaseLetters.length())));
        password.append(lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length())));
        password.append(digits.charAt(random.nextInt(digits.length())));
        password.append(specialCharacters.charAt(random.nextInt(specialCharacters.length())));

        // Rellenar el resto de la contraseña con caracteres aleatorios
        for (int i = 4; i < length; i++) {
            char nextChar;
            do {
                nextChar = allCharacters.charAt(random.nextInt(allCharacters.length()));
            } while (i > 0 && nextChar == password.charAt(i - 1)); // Evitar caracteres iguales consecutivos
            password.append(nextChar);
        }

        // Mezclar los caracteres para mayor aleatoriedad
        return shuffleString(password.toString());
    }

    public static String shuffleString(String input) {
        char[] characters = input.toCharArray();
        Random random = new Random();
        for (int i = 0; i < characters.length; i++) {
            int randomIndex = random.nextInt(characters.length);
            char temp = characters[i];
            characters[i] = characters[randomIndex];
            characters[randomIndex] = temp;
        }
        return new String(characters);
    }
}

